# Problem Set 4A
# Name:
# Collaborators:

from tree import Node # Imports the Node object used to construct trees

# Part A0: Data representation
# Fill out the following variables correctly.
# If correct, the test named test_data_representation should pass.
tree1 = Node(8, # value
    Node(
        2, Node(1), Node(6) ),
    Node(10))
tree2 = Node(7,                  # value
    Node(
        2, Node(1), Node(5,     # left  child
            Node(3), Node(6) )    # sub-tree of left child
    ),
    Node(
        9, Node(8), Node(10) ) # right child
)
tree3 = Node(5,                    # value
    Node(
        3, Node(2), Node(4) ),     # left  child

    Node(
        14, Node(12), Node(        # right child
            21,                    # sub-tree of right child
            Node(20),
            Node(26) ) )
)

tree_heap = Node(5,Node(15,None,Node(16,Node(30),Node(17))),Node(6,Node(20,None,Node(45)),Node(11)))
def find_tree_height(tree):
    '''
    Find the height of the given tree
    Input:
        tree: An element of type Node constructing a tree
    Output:
        The integer depth of the tree
    '''
    # TODO: Remove pass and write your code here
    if isinstance(tree, Node):
        left_child = tree.get_left_child()
        right_child = tree.get_right_child()
        if left_child == None and right_child == None:
            return 0
        elif right_child == None:
            return find_tree_height(left_child) + 1
        elif left_child == None:
            return find_tree_height(right_child) + 1
        return max(find_tree_height(left_child), find_tree_height(right_child)) + 1

def is_heap(tree, compare_func):
    '''
    Determines if the tree is a max or min heap depending on compare_func
    Inputs:
        tree: An element of type Node constructing a tree
        compare_func: a function that compares the child node value to the parent node value
            i.e. op(child_value,parent_value) for a max heap would return True if child_value < parent_value and False otherwise
                 op(child_value,parent_value) for a min meap would return True if child_value > parent_value and False otherwise
    Output:
        True if the entire tree satisfies the compare_func function; False otherwise
    '''

    left_child = tree.get_left_child()
    right_child = tree.get_right_child()
    lvalue, rvalue = True, True
    if left_child == None and right_child == None:
        return True

    if isinstance(left_child, Node):
        if compare_func(left_child.get_value(),tree.get_value()):
            print("tree: ", tree.get_value())
            print("left child: ", left_child.get_value())
            #print("right child: ", right_child.get_value())
            lvalue = is_heap(left_child, compare_func)
            print("lvalue: ", lvalue)
        else:
            return False
    if isinstance(right_child, Node):
        if compare_func(right_child.get_value(),tree.get_value()):
            print("tree: ", tree.get_value())
            #print("left child: ", left_child.get_value())
            print("right child: ", right_child.get_value())
            rvalue = is_heap(right_child, compare_func)
            print("rvalue: ", rvalue)
        else:
            return False
    print("lvalue & rvalue: ", lvalue, rvalue)
    return lvalue and rvalue



if __name__ == '__main__':
    # You can use this part for your own testing and debugging purposes.
    # IMPORTANT: Do not erase the pass statement below if you do not add your own code
    def compare_func(child_value, parent_value):
        if child_value > parent_value:
            print(f"Success comparing: {child_value}, {parent_value}")
            return True
        print(f"Failure comparing: {child_value}, {parent_value}")
        return False
    is_heap(tree_heap,compare_func)


#      /-----5------\
#     /              \
#    15               6
#   /  \             / \
#  None 16         20  11
#     /  \        /  \
#    30  17      None 45
