# Problem Set 2, hangman.py
# Name:
# Collaborators:
# Time spent:

import random
import string

# -----------------------------------
# HELPER CODE
# -----------------------------------

WORDLIST_FILENAME = "words.txt"

def load_words():
    """
    returns: list, a list of valid words. Words are strings of lowercase letters.

    Depending on the size of the word list, this function may
    take a while to finish.
    """
    print("Loading word list from file...")
    # inFile: file
    inFile = open(WORDLIST_FILENAME, 'r')
    # line: string
    line = inFile.readline()
    # wordlist: list of strings
    wordlist = line.split()
    print(" ", len(wordlist), "words loaded.")
    return wordlist

def choose_word(wordlist):
    """
    wordlist (list): list of words (strings)

    returns: a word from wordlist at random
    """
    return random.choice(wordlist)

# -----------------------------------
# END OF HELPER CODE
# -----------------------------------


# Load the list of words to be accessed from anywhere in the program
wordlist = load_words()

def has_player_won(secret_word, letters_guessed):
    """
    secret_word: string, the lowercase word the user is guessing
    letters_guessed: list (of lowercase letters), the letters that have been
        guessed so far

    returns: boolean, True if all the letters of secret_word are in letters_guessed,
        False otherwise
    """
    if len(secret_word) >= 0:
        if len(secret_word) == 0:
            return True
        count = 0
        for c in secret_word:
            if c in letters_guessed:
                count += 1
            if count >= len(secret_word):
                return True

    return False



def get_word_progress(secret_word, letters_guessed):
    """
    secret_word: string, the lowercase word the user is guessing
    letters_guessed: list (of lowercase letters), the letters that have been
        guessed so far

    returns: string, comprised of letters and asterisks (*) that represents
        which letters in secret_word have not been guessed so far
    """
    # FILL IN YOUR CODE HERE AND DELETE "pass"
    asterik_word = ''
    for i in range(len(secret_word)):
        if secret_word[i] in letters_guessed:
            asterik_word += secret_word[i]
        else:
            asterik_word += '*'
    return asterik_word



def get_available_letters(letters_guessed):
    """
    letters_guessed: list (of lowercase letters), the letters that have been
        guessed so far

    returns: string, comprised of letters that represents which
      letters have not yet been guessed. The letters should be returned in
      alphabetical order
    """
    not_guessed = ''
    for i in range(0,len(string.ascii_lowercase)):
        if string.ascii_lowercase[i] not in letters_guessed:
            not_guessed += string.ascii_lowercase[i]
    return not_guessed


def player_guess(secret_word, guesses, letters_guessed, with_help):
    """
    The core of the game, the part which handles user input and the correction of guesses.
    """

    pass

def helper_function(secret_word, available_letters):
    """
    The helper function.
    secret_word: the secret word, string.
    available_letters: the letters remaining, string.
    goal: make a helper function that provides the user with a letter to help them guess the secret word.
    implementation: create a string called choose_from, which consists of the unique letters between the available letters and the secret word.
                    Then, you will insert a couple of statements that pick a revealed_letter, then print 'Letter revealed: reavealed_letter' and the asterik word.
    """
    choose_from = ''
    for i in range(0,len(secret_word)):
        if secret_word[i] in available_letters:
            choose_from += secret_word[i]
    new = random.randint(0, len(choose_from)-1)
    revealed_letter = choose_from[new]
    return revealed_letter

def make_unique(word):
    unique = ''
    for e in word:
        if e not in unique:
            unique += e
    return unique

def hangman(secret_word, with_help):
    """
    secret_word: string, the secret word to guess.
    with_help: boolean, this enables help functionality if true.

    Starts up an interactive game of Hangman.

    * At the start of the game, let the user know how many
      letters the secret_word contains and how many guesses they start with.

    * The user should start with 10 guesses.

    * Before each round, you should display to the user how many guesses
      they have left and the letters that the user has not yet guessed.

    * Ask the user to supply one guess per round. Remember to make
      sure that the user puts in a single letter (or help character '!'
      for with_help functionality)

    * If the user inputs an incorrect consonant, then the user loses ONE guess,
      while if the user inputs an incorrect vowel (a, e, i, o, u),
      then the user loses TWO guesses.

    * The user should receive feedback immediately after each guess
      about whether their guess appears in the computer's word.

    * After each guess, you should display to the user the
      partially guessed word so far.

    -----------------------------------
    with_help functionality
    -----------------------------------
    * If the guess is the symbol !, you should reveal to the user one of the
      letters missing from the word at the cost of 3 guesses. If the user does
      not have 3 guesses remaining, print a warning message. Otherwise, add
      this letter to their guessed word and continue playing normally.

    Follows the other limitations detailed in the problem write-up.
    """
    # FILL IN YOUR CODE HERE AND DELETE "pass"
    letters_guessed = ''
    len_secret = len(secret_word)
    guesses = 10
    available_letters = get_available_letters(letters_guessed)
    word_progress = get_word_progress
    VOWELS = ['a','e','i','o','u']
    print("Welcome to Hangman!")
    print(f"I am thinking of a word that is {len_secret} letters long.")

    while guesses > 0:
        if '*' not in get_word_progress(secret_word, letters_guessed) and len(get_word_progress(secret_word, letters_guessed)) > 0:
             break
        print("------")
        print(f"You have {guesses} guesses left")
        print("Available letters:", available_letters)
        #print("DEBUG: Secret word:", secret_word)
        #print("DEBUG: Letters guessed:", letters_guessed)
        letter = input("Please guess a letter: ").lower()
        ##################### the stuff!! #####################
        if letter in secret_word and letter in available_letters:
            letters_guessed += letter
            print("Good guess:", word_progress(secret_word, letters_guessed))
            available_letters = get_available_letters(letters_guessed)

        elif letter == '!' and with_help:
            if guesses > 3:
                revealed_letter = helper_function(secret_word,available_letters)
                letters_guessed += revealed_letter # add it to the letters that are guessed to avoid repitition in helping
                available_letters = get_available_letters(letters_guessed) # a continuation of the line above, to avoid repitition in helping.
                print("Letter revealed: ",revealed_letter)
                print(get_word_progress(secret_word, letters_guessed)) # the asterik word
                guesses -= 3
            elif guesses <  3:
                print("Oops! Not enough guesses left:", get_word_progress(secret_word, letters_guessed))



        elif letter not in available_letters or not letter.isalpha():
            if letter in letters_guessed:
                print("Oops! You've already guessed that letter:", word_progress(secret_word, letters_guessed))
            else:
                print("Oops! That is not a valid letter. Please input a letter from the alphabet")



        else:
            if letter not in VOWELS:
                guesses -= 1
            else:
                guesses -= 2
            letters_guessed += letter
            print("Oops! That letter is not in my word:", word_progress(secret_word, letters_guessed))
            available_letters = get_available_letters(letters_guessed)

    print("------")
    if guesses > 0:
            print("Congratulations, you won!")
            total_score = (guesses + 4 * len(make_unique(secret_word))) + (3 * len(secret_word))
            print("Your total score for this game is:", total_score)
    if guesses <= 0:
            print(f"Sorry, you ran out of guesses. The word was {secret_word}.")


# When you've completed your hangman function, scroll down to the bottom
# of the file and uncomment the lines to test

if __name__ == "__main__":
    # To test your game, uncomment the following three lines.

    secret_word = "hi"
    with_help = False
    hangman(secret_word, with_help)

    # After you complete with_help functionality, change with_help to True
    # and try entering "!" as a guess!

    ###############

    # SUBMISSION INSTRUCTIONS
    # -----------------------
    # It doesn't matter if the lines above are commented in or not
    # when you submit your pset. However, please run ps2_student_tester.py
    # one more time before submitting to make sure all the tests pass.
    pass
