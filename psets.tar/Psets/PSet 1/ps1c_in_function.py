def part_c(initial_deposit):
	#########################################################################
	
	
	cost_of_dream_home = 800000
	portion_down_payment = 0.25
	real_cost = portion_down_payment * cost_of_dream_home
	epsilon = 100
	steps = 0
	r = 0.0
	amount_saved = 0
	low = 0.0
	high = 1.0
	##################################################################################################
	## Determine the lowest rate of return needed to get the down payment for your dream home below ##
	##################################################################################################
	
	
	while abs(real_cost - amount_saved) >= epsilon:
	    r = (low + high) / 2
	    steps += 1
	    amount_saved = initial_deposit * (1 + r / 12) ** 36
	    if int(amount_saved) > real_cost:
	        high = r
	    if int(amount_saved) < (real_cost):
	        low = r
	    if steps > 100:
	        r = None
	        break
	
	
	print(f"total steps taken {steps}")
	return r, steps