## 6.100A PSet 1: Part A
## Name:
## Time Spent:
## Collaborators:

##################################################################################
## Get user input for yearly_salary, portion_saved and cost_of_dream_home below ##
##################################################################################
yearly_salary = int(input("Enter your yearly salary"))
portion_saved = float(input("Enter the amount of money from salary saved")) # The portion of salary to be saved (decimal form)
cost_of_dream_home = int(input("Enter the cost of your dream home"))
#########################################################################
## Initialize other variables you need (if any) for your program below ##
#########################################################################

portion_down_payment = (0.25 * cost_of_dream_home) #  the percentage of the total cost needed for a down payment.
amount_saved = 0
monthly_salary = yearly_salary / 12
months = 0
###############################################################################################
## Determine how many months it would take to get the down payment for your dream home below ##
###############################################################################################

while(amount_saved <= portion_down_payment):

    r = ((0.05 * amount_saved))/12
    amount_saved += (portion_saved * monthly_salary)
    amount_saved += r
    months += 1
