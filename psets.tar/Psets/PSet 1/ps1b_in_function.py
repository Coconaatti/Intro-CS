def part_b(yearly_salary, portion_saved, cost_of_dream_home, semi_annual_raise):
	#########################################################################
	
	portion_down_payment = (0.25 * cost_of_dream_home) #  the percentage of the total cost needed for a down payment.
	amount_saved = 0
	
	months = 0
	###############################################################################################
	## Determine how many months it would take to get the down payment for your dream home below ##
	###############################################################################################
	
	while(amount_saved <= portion_down_payment):
	
	    monthly_salary = yearly_salary / 12
	    r = ((0.05 * amount_saved))/12
	    amount_saved += (portion_saved * monthly_salary)
	    amount_saved += r
	    months += 1
	    if (months % 6 == 0):
	        yearly_salary += semi_annual_raise * yearly_salary
	return months